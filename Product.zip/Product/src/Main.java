import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

class InsertDataIntoProduct {
    static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
    static final String USERNAME = "username";
    static final String PASSWORD = "password";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            // Inserting data into the Product table
            String insertQuery = "INSERT INTO Product (name, price_per_unit, active_for_sell) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                // Inserting the first product
                preparedStatement.setString(1, "Product 1");
                preparedStatement.setDouble(2, 10.50);
                preparedStatement.setBoolean(3, true);
                preparedStatement.executeUpdate();

                // Inserting the second product
                preparedStatement.setString(1, "Product 2");
                preparedStatement.setDouble(2, 15.75);
                preparedStatement.setBoolean(3, false);
                preparedStatement.executeUpdate();

                System.out.println("Data inserted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
